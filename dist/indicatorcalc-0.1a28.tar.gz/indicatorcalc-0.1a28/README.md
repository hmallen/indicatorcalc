# indicatorcalc

Centralized, TA-Lib based technical analysis indicator calculation from json market data.
