from .indicatorcalc import IndicatorCalc
from .indicatorcalc_redux import IndicatorCalc
