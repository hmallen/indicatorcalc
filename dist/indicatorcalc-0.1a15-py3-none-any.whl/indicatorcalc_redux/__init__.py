from .indicatorcalc_redux import IndicatorCalc
